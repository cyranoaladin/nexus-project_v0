# Nexus Réussite — Scaffold (MVP extension)
Ce dépôt contient un squelette complet pour démarrer l'extension Nexus Réussite :
- Backend **FastAPI** + **SQLAlchemy** + **Alembic**
- **OpenAPI** exhaustive (openapi.yaml)
- **RAG** (structure), **agents** (structure)
- **docker-compose** pour le dev local
- **Tickets Linear/Jira** (CSV) prêts à importer

## Démarrage rapide
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r apps/api/requirements.txt
export DATABASE_URL="postgresql+psycopg://nexus:nexus@localhost:5432/nexus"
alembic -c db/alembic.ini upgrade head
uvicorn apps.api.app.main:app --reload
```

## Services
- Postgres + pgvector
- MinIO (S3-like)
- Redis (events)

## Structure
Voir `tree.txt` pour une vue d'ensemble.
