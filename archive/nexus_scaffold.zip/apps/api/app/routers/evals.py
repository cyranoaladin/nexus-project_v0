from fastapi import APIRouter, Depends
from ..db.session import get_db
router = APIRouter()

@router.post("/generate")
def generate_eval(payload: dict, db=Depends(get_db)):
    # TODO
    return {"subject": payload.get("subject", "NSI"), "duration": 120}

@router.post("/grade")
def grade_eval(payload: dict, db=Depends(get_db)):
    # TODO: OCR grading pipeline
    return {"score": None, "feedback": []}
