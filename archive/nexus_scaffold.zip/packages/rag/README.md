# rag package — ingestion/indexation/retrieval + evaluation harness
